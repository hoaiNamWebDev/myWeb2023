<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nam</title>    
    <link rel="icon" type="image/jpeg"
    href="https://i.pinimg.com/750x/91/20/28/9120286173e0d7c343e7378c73865f15.jpg"/>
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"> -->
    
    
    <link rel="stylesheet" type="text/css" href="../view/css/footer.css">
    <link rel="stylesheet" type="text/css" href="../view/css/list.css">   
    <link rel="stylesheet" type="text/css" href="../view/css/style.css">
    <link rel="stylesheet" type="text/css" href="../view/css/add.css">
    <link rel="stylesheet" type="text/css" href="../view/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/fontawesome.min.css">
</head>
<body>
    <div class="boxcenter">
        <div class="row mb header">
            <h3>Nguyễn Hoài Nam</h3>       
        </div>
    
        <div class="row mb menu">
            <ul class="mb menu-second">
                <div class="menu-second--fleft">                    

                    <li><a href="index.php"><i class="fa-sharp fa-regular fa-book-open-cover menu-icon"></i></a></li>
                    <li><a href="index.php"><i class="fa-sharp fa-regular fa-book-open-cover menu-icon"></i></a></li>
                </div>            

                <li><a href="index.php"> Trang chủ</a></li>
                <li><a href="index.php?act=gioithieu">Giới thiệu</a></li>
                <li><a href="index.php?act=tintuc">Tài liệu</a></li>
                <li><a href="index.php?act=lienhe">Liên hệ</a></li>
                <li><a href="#">Tiểu sử</a></li>
                <div class="menu-second--fright">
                    <li><a href="index.php?act=thongbao"><i class="fa-regular fa-bell menu-icon"></i></a></li>               
                    <li><a href="index.php"><i class="fa-sharp fa-regular fa-book-open-cover menu-icon"></i></a></li>
                </div>  
            </ul>
        </div> 

    </div>
</body>
</html>
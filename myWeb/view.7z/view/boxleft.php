
<div class="row mb">
    <!-- <div class="boxtitle">Cá nhân</div> -->
    <img class="lboximg" src="https://i.pinimg.com/750x/91/20/28/9120286173e0d7c343e7378c73865f15.jpg" alt="" srcset="">
</div>
<div class="row mb">
    <div class="boxtitle">Profile</div>
    <h3>NGUYỄN HOÀI NAM</h3>
    <h3>01/09/2001</h3>
    <h3>Vĩnh Thạnh, Cần Thơ</h3>
    

</div>

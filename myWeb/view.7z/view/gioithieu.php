<div class="boxcenter">
    <div class="row">
        <div class="boxtitle">GIỚI THIỆU</div>
        <div class="row boxcontent">
            <div class="content_gioithieu">
                <p style="text-align: justify; margin-top: 0px;">
                    Trang web của Nguyễn Hoài Nam 
                </p>
                <p>
                    <strong>Kỹ năng</strong>
                </p>
                <p style="text-align: justify;">
                    • 
                    <br>
                    • 
                    <br>
                    • 
                </p>
                <p>
                    <strong>Sở thích</strong>
                </p>
                <p style="text-align: justify;">
                
                </p>
                <p>
                    <strong>Thói quen</strong>
                </p>                
                <p style="text-align: justify;">
               
                </p>
                <p>
                    <strong></strong>
                </p>
                <p style="text-align: justify;">
                
                </p>
            </div>
        </div>
    </div>
</div>
<div class="boxcenter">
    <div class="row">

        <div class="row mb">
            <div class="boxtrai mr">
                <?php
                include "boxleft.php";
                ?>
            </div>

            <div class="boxphai ">
                <div class="row mb">
                    <div class="boxtitle">
                        <a class="del_under" href="index.php">Trang chủ</a> >
                        <a class="del_under" href="index.php?act=tintuc">TÀI LIỆU</a>
                    </div>
                    <div class="row boxcontent-tintuc">
                    <?php
                        $linksp="index.php?act=tintucct&idtt=";                                                
                    ?>
                        <div class="boxnews">
                            <div class="boxnews-left-img"><a href="<?=$linksp?>3">
                                <img src="https://i.pinimg.com/750x/52/f5/fc/52f5fcb899c4f5cdaff0f7b1718ba66f.jpg" alt="">
                            </a></div>
                            <div class="boxnews-right-infor">
                                <a class="boxnews-title" href=""> </a>
                                <p class="boxnews-time">
                                    | <a href="index.php?act=tintuc">TÀI LIỆU</a> | <i>22 Bình luận</i></p>
                                <p class="boxnews-mota"></p>
                            </div>                                        
                        </div>
                        <div class="boxnews">
                            <div class="boxnews-left-img"><a href="<?=$linksp?>4">
                                <img src="https://i.pinimg.com/750x/8c/c0/36/8cc036816f9584113d2faa07d2c78ecb.jpg" alt="">
                            </a></div>
                            <div class="boxnews-right-infor">
                                <a class="boxnews-title" href=""> </a>
                                <p class="boxnews-time">
                                    | <a href="index.php?act=tintuc">TÀI LIỆU</a> | <i>22 Bình luận</i></p>
                                <p class="boxnews-mota"></p>
                            </div>                                        
                        </div>
                        <div class="boxnews">
                            <div class="boxnews-left-img"><a href="<?=$linksp?>1">
                                <img src="https://upload.wikimedia.org/wikipedia/en/thumb/3/30/Java_programming_language_logo.svg/121px-Java_programming_language_logo.svg.png" alt="">
                            </a></div>
                            <div class="boxnews-right-infor">
                                <a class="boxnews-title" href=""> </a>
                                <p class="boxnews-time">
                                    | <a href="index.php?act=tintuc">TÀI LIỆU</a> | <i>22 Bình luận</i></p>
                                <p class="boxnews-mota"></p>
                            </div>                                        
                        </div>
                    
                        <div class="boxnews">
                            <div class="boxnews-left-img"><a href="<?=$linksp?>2">
                                <img src="https://i.pinimg.com/750x/8f/1e/00/8f1e00778e1c166f3782c8254c8e5256.jpg" alt="">
                            </a></div>
                            <div class="boxnews-right-infor">
                                <a class="boxnews-title" href=""> </a>
                                <p class="boxnews-time">
                                    | <a href="index.php?act=tintuc">TÀI LIỆU</a> | <i>22 Bình luận</i></p>
                                <p class="boxnews-mota"></p>
                            </div>     

                        </div>
                    
                    </div>
                </div>

            </div>


        </div>

    </div>

</div>